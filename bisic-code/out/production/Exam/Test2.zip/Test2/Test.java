package Test2;

public class Test {
    public static void main(String[] args) {
        MobileGame mobileGame=new MobileGame();
        mobileGame.setType("竞技");
        mobileGame.setName("王者荣耀");
        mobileGame.paly();
        mobileGame.prepare();
    }
}
